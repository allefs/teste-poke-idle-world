POKÉ IDLE — MARKET MONITOR
==========================

O que faz
---------
- Consulta somente leitura o endpoint GET https://poke.idleworld.online/api/game/market?category=All
- Atualiza automaticamente a cada 30 segundos (2 consultas por minuto por navegador; o servidor local ainda mantém cache por 15 segundos).
- Filtros locais por busca, categoria, moeda, shiny, IV total, Quality, preço e nível.
- Ordenação por data, preço, IV, Quality, nível ou nome.
- Não envia compras, vendas, ofertas ou qualquer ação para o jogo.

Como abrir no Windows
---------------------
1. Extraia todos os arquivos do ZIP para uma pasta.
2. Instale Node.js LTS em https://nodejs.org/ caso ainda não tenha (uma instalação só).
3. Dê dois cliques em iniciar.bat.
4. O navegador abrirá http://127.0.0.1:3000.
5. Para encerrar, volte à janela preta do terminal e pressione Ctrl+C.

Requisitos e privacidade
------------------------
- Requer Node.js 18 ou superior (usa fetch nativo do Node).
- O servidor escuta apenas em 127.0.0.1, portanto não fica publicado na internet.
- Não armazena nem pede senha, cookie ou token de sessão.
- Se a API retornar 401/403 ou bloquear a consulta, o painel mostrará o erro. Nesse caso, será necessário confirmar com a equipe qual é o método oficial/autorizado de acesso; não cole cookies ou tokens no código.
- O acesso ao endpoint e o intervalo de atualização devem continuar de acordo com a autorização e os limites definidos pela equipe do jogo.

Arquivos
-------
server.js          servidor local e ponte para a API
public/index.html  interface, filtros e atualização automática
iniciar.bat        atalho para abrir no Windows

Hospedagem gratuita no Render
-----------------------------
1. Crie um repositório GitHub (recomendado: privado) e envie os arquivos desta pasta para a raiz do repositório.
2. No Render, escolha New > Web Service e conecte esse repositório.
3. Configure Runtime/Language como Node; Build Command: npm install; Start Command: npm start.
4. Selecione o plano Free e clique em Deploy.
5. O Render fornecerá um endereço público HTTPS.

O servidor já escuta em 0.0.0.0 e utiliza a variável PORT da plataforma.
No plano gratuito do Render, o serviço pode dormir após 15 minutos sem tráfego e demorar cerca de um minuto para voltar na primeira visita. Respeite sempre os limites de consulta autorizados pela equipe do jogo.
